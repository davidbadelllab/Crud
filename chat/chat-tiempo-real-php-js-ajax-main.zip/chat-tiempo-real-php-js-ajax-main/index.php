<?php 
  session_start();
 header("location: vistas/index.php");
?>
